// ==UserScript==
// @name         Live Exam OCR (Previews + Eng/Hin Text)
// @namespace    http://tampermonkey.net/
// @version      3.0
// @description  Unified floating panel with large image previews and offline bilingual OCR.
// @author       Vibe Coder
// @match        *://sarathi.parivahan.gov.in/*
// @require      https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // ==========================================
    // 1. BUILD THE UNIFIED UI PANEL
    // ==========================================
    const panel = document.createElement('div');
    panel.style.position = 'fixed';
    panel.style.bottom = '20px';
    panel.style.right = '20px';
    panel.style.width = '450px';
    panel.style.maxHeight = '90vh'; // Prevents it from going off-screen
    panel.style.overflowY = 'auto'; // Adds scrollbar if content gets too long
    panel.style.backgroundColor = 'rgba(15, 23, 42, 0.95)';
    panel.style.color = '#f8fafc';
    panel.style.padding = '15px';
    panel.style.borderRadius = '8px';
    panel.style.fontFamily = 'monospace';
    panel.style.fontSize = '14px';
    panel.style.boxShadow = '0 4px 10px rgba(0,0,0,0.5)';
    panel.style.zIndex = '999999';
    // pointer-events: auto allows scrolling inside the panel if needed
    panel.style.pointerEvents = 'auto';
    panel.style.border = '1px solid #334155';

    // Hide scrollbar visually for a cleaner look (Webkit)
    const style = document.createElement('style');
    style.innerHTML = `::-webkit-scrollbar { width: 6px; } ::-webkit-scrollbar-thumb { background: #475569; border-radius: 4px; }`;
    document.head.appendChild(style);

    panel.innerHTML = `
        <div style="font-weight: bold; border-bottom: 1px solid #475569; padding-bottom: 8px; margin-bottom: 8px; font-size: 16px;">
            👁️ VIBE OCR: PREVIEWS + TEXT
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
            <span id="ui-qno" style="font-weight: bold; color: #38bdf8;">Q No: Loading...</span>
            <span id="ui-score" style="font-weight: bold; color: #10b981;">Score: Loading...</span>
            <span id="ui-timer" style="font-weight: bold; color: #ef4444;">Timer: Loading...</span>
        </div>

        <div id="ui-img-container" style="display: none; border-top: 1px solid #475569; padding-top: 10px;">
            <div style="font-size: 12px; color: #94a3b8; margin-bottom: 4px;">LIVE IMAGES:</div>
            <img id="ui-q-preview" style="width: 100%; max-height: 150px; object-fit: contain; background: #fff; display: none; margin-bottom: 8px; border-radius: 4px; padding: 4px;" />
            <div style="display: flex; gap: 6px; flex-wrap: wrap;">
                <img id="ui-opt-1" style="width: 48%; max-height: 80px; object-fit: contain; background: #fff; display: none; border-radius: 4px; padding: 2px;" />
                <img id="ui-opt-2" style="width: 48%; max-height: 80px; object-fit: contain; background: #fff; display: none; border-radius: 4px; padding: 2px;" />
                <img id="ui-opt-3" style="width: 48%; max-height: 80px; object-fit: contain; background: #fff; display: none; border-radius: 4px; padding: 2px;" />
                <img id="ui-opt-4" style="width: 48%; max-height: 80px; object-fit: contain; background: #fff; display: none; border-radius: 4px; padding: 2px;" />
            </div>
        </div>

        <div style="margin-top: 12px; border-top: 1px solid #475569; padding-top: 10px;">
            <div style="font-size: 12px; color: #f59e0b; margin-bottom: 4px;" id="ocr-status">OCR Status: Waiting...</div>
            <div id="ocr-output-q" style="background: #1e293b; padding: 8px; border-radius: 4px; margin-bottom: 8px; color: #fbbf24; min-height: 40px; white-space: pre-wrap;">Question text will appear here...</div>
            <div id="ocr-output-opts" style="background: #1e293b; padding: 8px; border-radius: 4px; color: #60a5fa; min-height: 40px; white-space: pre-wrap;">Options text will appear here...</div>
        </div>
    `;

    document.body.appendChild(panel);

    // DOM Refs
    const uiQno = document.getElementById('ui-qno');
    const uiScore = document.getElementById('ui-score');
    const uiTimer = document.getElementById('ui-timer');
    const uiImgContainer = document.getElementById('ui-img-container');
    const uiQPreview = document.getElementById('ui-q-preview');
    const ocrStatus = document.getElementById('ocr-status');
    const ocrOutputQ = document.getElementById('ocr-output-q');
    const ocrOutputOpts = document.getElementById('ocr-output-opts');

    // ==========================================
    // 2. OCR ENGINE LOGIC
    // ==========================================
    let lastProcessedQuestion = null;
    let isProcessing = false;

    async function runLocalOCR(data) {
        if (isProcessing || !data.questionImg || data.questionImg === lastProcessedQuestion) return;

        isProcessing = true;
        lastProcessedQuestion = data.questionImg;
        ocrStatus.innerText = "OCR Status: ⚙️ Processing (Downloading Hin pack if 1st run)...";
        ocrStatus.style.color = "#f59e0b";

        try {
            const worker = await Tesseract.createWorker('eng+hin');

            ocrStatus.innerText = "OCR Status: ⚙️ Reading Question...";
            const retQ = await worker.recognize(data.questionImg);
            ocrOutputQ.innerText = "Q: " + retQ.data.text.trim();

            ocrStatus.innerText = "OCR Status: ⚙️ Reading Options...";
            let optsText = "";
            for (let i = 0; i < data.optionsImg.length; i++) {
                if (data.optionsImg[i]) {
                    const retOpt = await worker.recognize(data.optionsImg[i]);
                    optsText += `[${i+1}] ${retOpt.data.text.trim()}\n`;
                }
            }
            ocrOutputOpts.innerText = optsText;

            await worker.terminate();
            ocrStatus.innerText = "OCR Status: ✅ Complete";
            ocrStatus.style.color = "#10b981";

        } catch (err) {
            console.error(err);
            ocrStatus.innerText = "OCR Status: ❌ Failed";
            ocrStatus.style.color = "#ef4444";
        } finally {
            isProcessing = false;
        }
    }

    // ==========================================
    // 3. THE DATA ENGINE
    // ==========================================
    function getExamData() {
        const questionNo = document.querySelector('span.mytext1')?.innerText.trim() || 'N/A';
        const score = document.querySelector('h3.text-success')?.innerText.trim() || 'N/A';
        const timer = document.getElementById('timer')?.innerText.trim() || '0';
        const questionImg = document.querySelector('img[name="qframe"]')?.src || null;
        const optionsImg = [1, 2, 3, 4].map(i => {
            const el = document.getElementById(`choice${i}`);
            return el ? el.src : null;
        });

        return { questionNo, score, timer, questionImg, optionsImg };
    }

    setInterval(() => {
        const data = getExamData();

        // Update Text
        uiQno.innerText = `Q No: ${data.questionNo}`;
        uiScore.innerText = `Score: ${data.score}`;
        uiTimer.innerText = `Timer: ${data.timer}s`;

        // Update Images
        const hasQuestion = !!data.questionImg;
        const validOptions = data.optionsImg.filter(Boolean);

        if (hasQuestion || validOptions.length > 0) {
            uiImgContainer.style.display = 'block';

            if (hasQuestion) {
                uiQPreview.src = data.questionImg;
                uiQPreview.style.display = 'block';
            } else {
                uiQPreview.style.display = 'none';
            }

            for (let i = 0; i < 4; i++) {
                const optImgElement = document.getElementById(`ui-opt-${i+1}`);
                if (data.optionsImg[i]) {
                    optImgElement.src = data.optionsImg[i];
                    optImgElement.style.display = 'block';
                } else {
                    optImgElement.style.display = 'none';
                }
            }
        } else {
            uiImgContainer.style.display = 'none';
        }

        // Trigger OCR if needed
        if (data.questionImg && data.questionImg !== lastProcessedQuestion && !isProcessing) {
            runLocalOCR(data);
        }

        // Expose payload for external tools
        window.__LIVE_OCR_PAYLOAD = data;

    }, 500);

})();
