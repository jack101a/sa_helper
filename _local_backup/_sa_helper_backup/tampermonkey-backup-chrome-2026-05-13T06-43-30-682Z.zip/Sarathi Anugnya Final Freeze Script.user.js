// ==UserScript==
// @name         Sarathi Anugnya Final Freeze Script
// @namespace    http://tampermonkey.net/
// @version      5.0
// @description  Freeze page before exit button, auto-focus captcha input for LL form.
// @author       You
// @match        https://sarathi.parivahan.gov.in/sarathiservice/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function () {
    'use strict';

    let frozen = false;
    let observer = null;

    console.log("🚀 Final Script Loaded");

    // --- Neutralize early exit/reload detections ---
    Object.defineProperty(document, "hidden", { value: false });
    Object.defineProperty(document, "visibilityState", { value: "visible" });

    window.onbeforeunload = null;
    window.onunload = null;
    window.performance.getEntriesByType = () => [];
    window.performance.navigation = { type: 0 };

    // --- Freeze everything ---
    function freezePage() {
        if (frozen) return;
        frozen = true;

        // Kill timers
        window.setTimeout = () => 0;
        window.setInterval = () => 0;

        // Block network
        window.XMLHttpRequest = function () {
            return { open() { }, send() { }, abort() { } };
        };
        window.fetch = () => new Promise(() => { });

        if (observer) observer.disconnect();

        console.log("⏸ Page Frozen BEFORE exit button");
        alert("✅ Page frozen. Captcha ready, exit button won't appear.");
    }

    // --- Detect applNumber + captcha ---
    function checkInputs() {
        const appl = document.querySelector('input[name="applNumber"]');
        const captcha = document.querySelector('input[name="captcha"]');

        if (appl && captcha) {
            console.log("✅ Inputs Found, Freezing Page...");

            freezePage();

            // Auto-focus captcha input
            setTimeout(() => {
                captcha.focus();
                captcha.style.border = "2px solid red";
            }, 100);

            return true;
        }
        return false;
    }

    // --- Main init ---
    function init() {
        if (location.href.includes("authtype=Anugnya")) {
            if (checkInputs()) return;

            observer = new MutationObserver(() => {
                if (!frozen) checkInputs();
            });
            observer.observe(document, { childList: true, subtree: true });

            document.addEventListener("DOMContentLoaded", () => {
                if (!frozen) checkInputs();
            });

            window.addEventListener("load", () => {
                if (!frozen) checkInputs();
            });
        }
    }

    init();
})();