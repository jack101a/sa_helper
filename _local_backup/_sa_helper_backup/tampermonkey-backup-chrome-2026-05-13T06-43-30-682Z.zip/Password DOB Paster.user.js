// ==UserScript==
// @name        Password DOB Paster
// @namespace   http://tampermonkey.net/
// @version     2025-10-31
// @description वेबसाइटों पर password और DOB फील्ड में paste रोक लागू करने वाले handlers हटाकर paste allow करने का स्क्रिप्ट
// @author      You
// @match       https://sarathi.parivahan.gov.in/*/*
// @icon        https://www.google.com/s2/favicons?sz=64&domain=gov.in
// @grant       none
// ==/UserScript==

(function () {
    'use strict';

    // Remove inline oncopy/onpaste/oncut handlers from all elements
    function removeInlineHandlers() {
        document.querySelectorAll('*').forEach(el => {
            try {
                el.oncopy = null;
                el.onpaste = null;
                el.oncut = null;
            } catch (err) {
                // ignore read-only properties
            }
        });
    }

    // Allow paste specifically for password and DOB-like inputs by intercepting paste in capture phase
    function addPasteAllowHandler() {
        // capture-phase listener so it runs before site's handlers
        document.addEventListener('paste', function (e) {
            const t = e.target;
            if (!t || !(t.tagName === 'INPUT' || t.tagName === 'TEXTAREA')) return;

            const nameIdPlaceholder = ((t.name || '') + ' ' + (t.id || '') + ' ' + (t.placeholder || '')).toLowerCase();

            const looksLikeDob = /dob|dateofbirth|date-of-birth|birthdate|birth-date|date/i.test(nameIdPlaceholder) || t.type === 'date';
            const isPassword = t.type === 'password' || /pass|pwd/.test(nameIdPlaceholder);

            if (isPassword || looksLikeDob) {
                // prevent any site listener from stopping the paste by stopping propagation,
                // but do NOT call preventDefault() so paste proceeds normally.
                e.stopImmediatePropagation();
                // (Optional) some sites cancel the event via timeout or other tricks; try a micro-delay fallback:
                // allow default behavior; if needed we could programmatically insert clipboard content (not done here)
            }
        }, true); // true => capture phase
    }

    // Run initial cleanup + handlers
    removeInlineHandlers();
    addPasteAllowHandler();

    // Observe DOM changes and re-apply cleanup for dynamically inserted elements
    const observer = new MutationObserver(() => {
        removeInlineHandlers();
    });

    observer.observe(document.documentElement || document.body, {
        childList: true,
        subtree: true,
    });

})();