// ==UserScript==
// @name         Var Conn - Developed By CHANDRAKANT H
// @namespace    http://tampermonkey.net/
// @version      1.4
// @description  Sarathi WebSocket Authentication - Developed By HI-TECH SOLUTION
// @author       HI-TECH SOLUTION
// @match        https://sarathi.parivahan.gov.in/sarathiservice/authenticationaction.do*
// @grant        none
// @require      https://cdnjs.cloudflare.com/ajax/libs/js-sha256/0.9.0/sha256.min.js
// ==/UserScript==

/* ===============================================
   VAR CONN
   Developed By HI-TECH SOLUTION
   Website: https://sarathi.parivahan.gov.in/
   =============================================== */

(function() {
    'use strict';

    console.log('Var Conn - Developed By CHANDRAKANT H - Script loaded!');

    let socket;
    let serverToken;
    let isStableMode = true; // New flag to keep page stable

    // Developed By HI-TECH SOLUTION - Var Conn System
    window.create_hs = function(appl_no, authType) {
        console.log('Var Conn - create_hs called:', appl_no, authType);

        var smartDiv = document.getElementById('smartLock');
        var faceAuth = document.getElementById('faceAuthReq');
        var proctorReq = document.getElementById('proctorReq');

        if(authType==='Anugyna')
        {
            socket = new WebSocket('ws://localhost:8000/');
            var smartLogout = document.getElementById('smartLogout');
            if(smartLogout) smartLogout.style.display = "block";
        }
        if(authType==="faceAuthReq")
        {
            if(faceAuth) faceAuth.style.display = "block";
            var smartLogout = document.getElementById('smartLogout');
            if(smartLogout) smartLogout.style.display = "none";
        }
        else if(authType!='Anugyna')
        {
            var smartNoExam = document.getElementById('smartNoExam');
            var NoFaceAuthReq = document.getElementById('NoFaceAuthReq');
            var smartcompleteFlow = document.getElementById('smartcompleteFlow');
            var scheduleDate = document.getElementById('scheduleDate');
            var faceauthmaxtimeallowed = document.getElementById('faceauthmaxtimeallowed');
            var smartfaceauthmaxtimeallowedDL = document.getElementById('smartfaceauthmaxtimeallowedDL');
            var faceauthmaxtimeallowedslot = document.getElementById('faceauthmaxtimeallowedslot');
            var alreadyCompleted = document.getElementById('alreadyCompleted');
            var expiredApplication = document.getElementById('expiredApplication');
            var smartphotoUpload = document.getElementById('smartphotoUpload');
            var capturePhoto = document.getElementById('capturePhoto');
            var maxLogins = document.getElementById('maxLogins');
            var quotaFlag = document.getElementById('quotaFlag');
            var photoUpload = document.getElementById('photoUpload');
            var completeFlow = document.getElementById('completeFlow');
            var NoExam = document.getElementById('NoExam');
            var faceauthmaxtimeallowedDL = document.getElementById('faceauthmaxtimeallowedDL');
            var smartLogout = document.getElementById('smartLogout');

            if(authType==="NoExam")
            {
                if(smartNoExam) smartNoExam.style.display = "block";
                if(NoFaceAuthReq) NoFaceAuthReq.style.display = "none";
            }
            else if(authType==="completeFlow")
            {
                if(smartcompleteFlow) smartcompleteFlow.style.display = "block";
                if(NoFaceAuthReq) NoFaceAuthReq.style.display = "none";
            }
            else if(authType==="scheduleDate")
            {
                if(scheduleDate) scheduleDate.style.display = "block";
                if(NoFaceAuthReq) NoFaceAuthReq.style.display = "none";
            }
            else if(authType==="NOfaceAuthReq")
            {
                if(NoFaceAuthReq) NoFaceAuthReq.style.display = "block";
            }
            else if(authType==="bioAuth")
            {
                if(NoFaceAuthReq) NoFaceAuthReq.style.display = "block";
            }
            else if(authType==="attemptMaxtimes")
            {
                if(faceauthmaxtimeallowed) faceauthmaxtimeallowed.style.display = "block";
                if(NoFaceAuthReq) NoFaceAuthReq.style.display = "none";
            }
            else if(authType==="attemptMaxtimeDL")
            {
                if(smartfaceauthmaxtimeallowedDL) smartfaceauthmaxtimeallowedDL.style.display = "block";
                if(NoFaceAuthReq) NoFaceAuthReq.style.display = "none";
            }
            else if(authType==="attemptMaxtimeslot")
            {
                if(faceauthmaxtimeallowedslot) faceauthmaxtimeallowedslot.style.display = "block";
                if(NoFaceAuthReq) NoFaceAuthReq.style.display = "none";
            }
            else if(authType==="alreadyCompleted")
            {
                if(alreadyCompleted) alreadyCompleted.style.display = "block";
                if(NoFaceAuthReq) NoFaceAuthReq.style.display = "none";
            }
            else if(authType==="expiredApplication")
            {
                if(expiredApplication) expiredApplication.style.display = "block";
                if(NoFaceAuthReq) NoFaceAuthReq.style.display = "none";
            }
            else if(authType==="photoUpload")
            {
                if(smartphotoUpload) smartphotoUpload.style.display = "block";
                if(NoFaceAuthReq) NoFaceAuthReq.style.display = "none";
            }
            else if(authType==="capturePhoto")
            {
                if(capturePhoto) capturePhoto.style.display = "block";
                if(NoFaceAuthReq) NoFaceAuthReq.style.display = "none";
            }
            if(authType==="maxLogins")
            {
                if(maxLogins) maxLogins.style.display = "block";
                if(NoFaceAuthReq) NoFaceAuthReq.style.display = "none";
            }
            if(authType==="quotaFlag")
            {
                if(quotaFlag) quotaFlag.style.display = "block";
                if(NoFaceAuthReq) NoFaceAuthReq.style.display = "none";
            }

            if(photoUpload) photoUpload.style.display = "none";
            if(completeFlow) completeFlow.style.display = "none";
            if(NoExam) NoExam.style.display = "none";
            if(faceauthmaxtimeallowedDL) faceauthmaxtimeallowedDL.style.display = "none";
            if(faceauthmaxtimeallowedslot) faceauthmaxtimeallowedslot.style.display = "none";
            if(faceAuth) faceAuth.style.display = "none";
            if(proctorReq) proctorReq.style.display = "none";
            if(smartLogout) smartLogout.style.display = "block";
        }

        // WebSocket events - Developed By HI-TECH SOLUTION
        if(socket) {
            socket.addEventListener('open', function (ev) {
                if(authType==='Anugyna' && appl_no!=null)
                {
                    var reqOb = new Object();
                    reqOb.type = "Authentication";
                    reqOb.token = '1234';
                    serverToken = "12345";
                    reqOb.userid = appl_no;
                    var request = JSON.stringify(reqOb);
                    socket.send(request);
                    if(smartDiv) smartDiv.style.display = "none";
                    sessionStorage.setItem('authType', 'Anugyna');
                    console.log('Var Conn - WebSocket connected successfully!');
                }
            });

            socket.addEventListener('message', function (event) {
                var res = JSON.parse(event.data);
                if (res['type'] == 'Authentication') {
                    if (sha256(serverToken) == res['token_hash']) {
                        console.log('Var Conn - Authentication successful!');
                    } else {
                        console.log('Var Conn - Authentication failed!');
                    }
                }
            });

            socket.addEventListener("close", function (event) {
                handleDisconnect(authType, appl_no);
            });

            socket.addEventListener("error", function (event) {
                handleDisconnect(authType, appl_no);
            });
        }
    };

    function handleDisconnect(authType, appl_no) {
        // Don't clear session storage immediately
        // sessionStorage.clear();

        if(authType==='Anugyna' && appl_no==='12345')
        {
            var pname = window.location.pathname.split('/');
            var newurl = window.location.origin+"/"+pname[1]+"/403.jsp";
        }
        else
        {
            // Only hide elements if not in stable mode
            if (!isStableMode) {
                hideAllElements();
            } else {
                console.log("Var Conn - Stable mode active, elements preserved");
            }
        }
        console.log("Var Conn - WebSocket disconnected!");
    }

    function hideAllElements() {
        var elements = [
            'smartLock', 'faceAuthReq', 'proctorReq', 'smartLogout',
            'NoFaceAuthReq', 'maxLogins', 'capturePhoto', 'photoUpload',
            'alreadyCompleted', 'expiredApplication', 'faceauthmaxtimeallowedslot',
            'faceauthmaxtimeallowedDL', 'faceauthmaxtimeallowed', 'scheduleDate',
            'completeFlow', 'NoExam', 'smartphotoUpload', 'smartcompleteFlow',
            'smartNoExam', 'smartfaceauthmaxtimeallowedDL', 'smartfaceauthmaxtimeallowedslot'
        ];

        elements.forEach(function(id) {
            var element = document.getElementById(id);
            if(element) element.style.display = "none";
        });
    }

    // Var Conn - applStatus function
    window.applStatus = function(url, slot, appl_no) {
        console.log('Var Conn - applStatus called');

        if(!socket) {
            console.error('Var Conn - WebSocket not initialized');
            return;
        }

        var actualApplNo, actualSlot;

        if(arguments.length === 1) {
            actualApplNo = document.forms["authentication"]["llappln"].value;
            actualSlot = null;
            url = arguments[0];
        } else {
            actualApplNo = appl_no;
            actualSlot = slot;
        }

        var newobj = new Object();
        newobj.type = 'GenerateLicence';
        newobj.userid = actualApplNo;

        if(actualSlot == "slots") {
            newobj.url = location.origin + "//" + url;
        } else {
            newobj.url = location.origin + location.pathname.slice(0, window.location.pathname.lastIndexOf('/') + 1) + url;
        }

        var newrequest = JSON.stringify(newobj);

        setTimeout(() => {
            if(socket.readyState === WebSocket.OPEN) {
                socket.send(newrequest);
                console.log('Var Conn - License request sent!');

                // Disable stable mode when moving to next page
                isStableMode = false;
            }
        }, actualSlot ? 1000 : 0);
    };

    // Var Conn - Logout function
    window.logout = function() {
        console.log('Var Conn - Logout called');
        isStableMode = false; // Disable stable mode on logout

        if(socket && socket.readyState === WebSocket.OPEN) {
            setTimeout(() => {
                socket.send('{"type":"LOGOUT"}');
                console.log('Var Conn - Logout successful!');
            }, 1000);
        }
    };

    // Function to preserve current page state
    function preservePageState() {
        console.log('Var Conn - Preserving page state');

        // Store current visibility state of important elements
        var importantElements = [
            'smartLock', 'faceAuthReq', 'proctorReq', 'smartLogout',
            'NoFaceAuthReq', 'smartNoExam', 'smartcompleteFlow'
        ];

        importantElements.forEach(function(id) {
            var element = document.getElementById(id);
            if(element && element.style.display !== "none") {
                console.log('Preserving element:', id);
                // Force the element to remain visible
                element.style.display = "block";
            }
        });
    }

    // Auto-execute for Var Conn with page preservation
    setTimeout(function() {
        var urlParams = new URLSearchParams(window.location.search);
        var authType = urlParams.get('authtype');

        // Preserve current page state
        preservePageState();

        if(authType === 'Anugyna') {
            console.log('Var Conn - Auto-detected Anugyna authentication');
            var applNo = document.forms["authentication"]?.elements["llappln"]?.value;
            if(applNo) {
                window.create_hs(applNo, 'Anugyna');
            }
        }

        // Continuously check and preserve page state
        setInterval(preservePageState, 1000);

    }, 2000);

})();