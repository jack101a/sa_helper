// ==UserScript==
// @name         Unlock Name of Applicant Field - Voters Portal
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Unlock disabled/readonly applicant name field on voters portal
// @match        https://voters.eci.gov.in/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    function unlockField() {
        let el = document.querySelector('input[name="nameofApplicant"]');
        if (el) {
            el.removeAttribute('disabled');
            el.removeAttribute('readonly');
            el.readOnly = false;
            el.style.background = "#ffffff";
            el.style.border = "1px solid #000";

            console.log("✔ Name of Applicant field unlocked!");
        }
    }

    // Keep unlocking (Angular/JS relocks frequently)
    setInterval(unlockField, 1000);
})();