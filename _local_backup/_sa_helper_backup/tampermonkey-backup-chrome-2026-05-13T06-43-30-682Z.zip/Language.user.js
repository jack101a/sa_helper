// ==UserScript==
// @name         Language
// @namespace    http://tampermonkey.net/
// @version      2025-07-29
// @description  try to take over the world!
// @author       You
// @match        https://sarathi.parivahan.gov.in/sarathiservice/instruction.do
// @icon         https://www.google.com/s2/favicons?sz=64&domain=gov.in
// @grant        none
// ==/UserScript==

(function() {
  'use strict';

  const languageSelect = document.getElementById("language");
    languageSelect.value = "MARATHI";
  languageSelect.dispatchEvent(new Event('change'));

  // Tick both checkboxes
  ["disclaimer1", "disclaimer2"].forEach(name => {
    const checkbox = document.getElementsByName(name)[0];
    checkbox.checked = true;
    checkbox.dispatchEvent(new Event('click'));
  });

  // Wait briefly (to allow enableproceed() to run), then click CONTINUE
  setTimeout(() => {
    document.getElementById("subm").click();
  }, 300); // Adjust if needed

})();