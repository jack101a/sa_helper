// ==UserScript==
// @name         Sarathi Advanced Anti-Debugger Bypass
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Bypass anti-debugger and pause on Sarathi Parivahan automatically
// @author       Copilot
// @match        ://.parivahan.gov.in/*
// @match        ://.sarathi.parivahan.gov.in/*
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    // Patch Function constructor to remove debugger statements
    const OriginalFunction = Function;
    window.Function = function(...args) {
        if (args.length) {
            args = args.map(arg => typeof arg === "string" ? arg.replace(/debugger\s*;?/gi, '') : arg);
        }
        return OriginalFunction(...args);
    };

    // Patch eval to remove debugger statements
    const OriginalEval = window.eval;
    window.eval = function(code) {
        if (typeof code === 'string') code = code.replace(/debugger\s*;?/gi, '');
        return OriginalEval(code);
    };

    // Patch setInterval & setTimeout to remove debugger in string code
    const origSetInterval = window.setInterval;
    window.setInterval = function(fn, t, ...rest) {
        if (typeof fn === 'string') fn = fn.replace(/debugger\s*;?/gi, '');
        return origSetInterval(fn, t, ...rest);
    };
    const origSetTimeout = window.setTimeout;
    window.setTimeout = function(fn, t, ...rest) {
        if (typeof fn === 'string') fn = fn.replace(/debugger\s*;?/gi, '');
        return origSetTimeout(fn, t, ...rest);
    };

    // Hide and freeze the 'debugger' property
    Object.defineProperty(window, 'debugger', {
        get: function() { return undefined; },
        set: function() {},
        configurable: false,
        enumerable: false
    });

    // Try to auto-resume if paused
    setInterval(() => {
        window.blur();
        window.focus();
        try { if (typeof window.resume === "function") window.resume(); } catch (e) {}
    }, 1000);

    // Patch addEventListener to skip listeners with debugger
    const origAddEventListener = EventTarget.prototype.addEventListener;
    EventTarget.prototype.addEventListener = function(type, listener, options) {
        if (typeof listener === 'function' && listener.toString().includes('debugger')) {
            return;
        }
        return origAddEventListener.call(this, type, listener, options);
    };
})();