// ==UserScript==
// @name         Continue
// @namespace    http://tampermonkey.net/
// @version      2025-07-29
// @description  try to take over the world!
// @author       You
// @match        https://sarathi.parivahan.gov.in/sarathiservice/authenticationaction.do
// @icon         https://www.google.com/s2/favicons?sz=64&domain=gov.in
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    document.querySelector('input[type="submit"][value="CONTINUE"]').click();
})();